<?php
session_start();
include '../../../koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'checker') {
    header('Location: ../auth/login.php');
    exit;
}

$today = date('Y-m-d');

// Mobil yang akan diambil (before check)
$sql_before = "SELECT b.id AS booking_id, u.plat_nomor, us.nama_lengkap, b.jam_booking
    FROM booking b
    JOIN unit_mobil u ON b.unit_mobil_id = u.id
    JOIN users us ON b.customer_id = us.id
    WHERE DATE(b.tgl_booking) = '$today'";
$result_before = mysqli_query($db, $sql_before);

// Mobil yang akan kembali (after check)
$sql_after = "SELECT b.id AS booking_id, u.plat_nomor, us.nama_lengkap, b.jam_kembali
    FROM booking b
    JOIN unit_mobil u ON b.unit_mobil_id = u.id
    JOIN users us ON b.customer_id = us.id
    WHERE DATE(b.tgl_kembali) = '$today'";
$result_after = mysqli_query($db, $sql_after);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Dashboard Checker</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th,
        td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #f0f0f0;
        }

        h2 {
            margin-top: 40px;
        }

        .btn {
            padding: 6px 12px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>
    <h1>Dashboard Checker</h1>

    <h2>Mobil Akan Diambil Hari Ini (Before Check)</h2>
    <table>
        <tr>
            <th>Plat Nomor</th>
            <th>Nama Customer</th>
            <th>Jam Ambil</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result_before)) { ?>
            <tr>
                <td><?= htmlspecialchars($row['plat_nomor']) ?></td>
                <td><?= htmlspecialchars($row['nama_lengkap']) ?></td>
                <td><?= htmlspecialchars($row['jam_booking']) ?></td>
                <td><a class="btn" href="inspeksi.php?booking_id=<?= $row['booking_id'] ?>&tipe=before">Periksa</a></td>
            </tr>
        <?php } ?>
    </table>

    <h2>Mobil Akan Kembali Hari Ini (After Check)</h2>
    <table>
        <tr>
            <th>Plat Nomor</th>
            <th>Nama Customer</th>
            <th>Jam Kembali</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result_after)) { ?>
            <tr>
                <td><?= htmlspecialchars($row['plat_nomor']) ?></td>
                <td><?= htmlspecialchars($row['nama_lengkap']) ?></td>
                <td><?= htmlspecialchars($row['jam_kembali']) ?></td>
                <td><a class="btn" href="inspeksi.php?booking_id=<?= $row['booking_id'] ?>&tipe=after">Periksa</a></td>
            </tr>
        <?php } ?>
    </table>
</body>

</html>