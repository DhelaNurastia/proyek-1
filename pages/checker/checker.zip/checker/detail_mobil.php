<?php
session_start();
include '../../../koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'checker') {
    header('Location: ../../pages/Halaman_Register&Login');
    exit;
}

$id_mobil = $_GET['id'] ?? null;
if (!$id_mobil) {
    echo "ID mobil tidak ditemukan.";
    exit;
}

// Data unit mobil
$sql_mobil = "SELECT u.*, j.nama_jenis FROM unit_mobil u
              LEFT JOIN jenis_mobil j ON u.jenis_mobil_id = j.id
              WHERE u.id = $id_mobil";
$result_mobil = mysqli_query($conn, $sql_mobil);
$mobil = mysqli_fetch_assoc($result_mobil);
if (!$mobil) {
    echo "Mobil tidak ditemukan.";
    exit;
}

// Riwayat booking + inspeksi mobil
$sql_riwayat = "SELECT b.*, i.kondisi_pre, i.kondisi_post, i.catatan, i.denda, us.nama_lengkap
                FROM booking b
                LEFT JOIN inspeksi i ON i.booking_id = b.id
                LEFT JOIN users us ON b.customer_id = us.id
                WHERE b.unit_mobil_id = $id_mobil
                ORDER BY b.tgl_booking DESC";
$result_riwayat = mysqli_query($conn, $sql_riwayat);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Detail Mobil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 8px;
            border: 1px solid #ccc;
        }

        th {
            background: #eee;
        }

        h2 {
            margin-top: 30px;
        }
    </style>
</head>

<body>
    <h1>Detail Mobil - <?= htmlspecialchars($mobil['plat_nomor']) ?></h1>
    <p><strong>Merk:</strong> <?= htmlspecialchars($mobil['merk']) ?></p>
    <p><strong>Jenis:</strong> <?= htmlspecialchars($mobil['nama_jenis']) ?></p>
    <p><strong>Warna:</strong> <?= htmlspecialchars($mobil['warna']) ?></p>
    <p><strong>No. STNK:</strong> <?= htmlspecialchars($mobil['no_stnk']) ?></p>
    <p><strong>Status:</strong> <?= htmlspecialchars($mobil['status']) ?></p>

    <h2>Riwayat Booking & Pemeriksaan</h2>
    <table>
        <tr>
            <th>Customer</th>
            <th>Tgl Booking</th>
            <th>Tgl Kembali</th>
            <th>Kondisi Sebelum</th>
            <th>Kondisi Setelah</th>
            <th>Catatan</th>
            <th>Denda</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result_riwayat)) { ?>
            <tr>
                <td><?= htmlspecialchars($row['nama_lengkap']) ?></td>
                <td><?= date('d-m-Y', strtotime($row['tgl_booking'])) ?></td>
                <td><?= date('d-m-Y', strtotime($row['tgl_kembali'])) ?></td>
                <td><?= ucfirst($row['kondisi_pre'] ?? '-') ?></td>
                <td><?= ucfirst($row['kondisi_post'] ?? '-') ?></td>
                <td>
                    <pre><?= htmlspecialchars($row['catatan']) ?></pre>
                </td>
                <td><?= $row['denda'] > 0 ? 'Rp ' . number_format($row['denda'], 0, ',', '.') : '-' ?></td>
            </tr>
        <?php } ?>
    </table>
</body>

</html>