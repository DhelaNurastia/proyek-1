<?php
session_start();
include '../../../koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'checker') {
    header('Location: ../auth/login.php');
    exit;
}

$booking_id = $_GET['booking_id'] ?? null;
$tipe = $_GET['tipe'] ?? null; // 'before' atau 'after'

if (!$booking_id || !in_array($tipe, ['before', 'after'])) {
    die('Parameter tidak valid');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $catatan = mysqli_real_escape_string($db, $_POST['catatan']);
    $kondisi = $_POST['kondisi'];
    $denda = isset($_POST['denda']) ? intval($_POST['denda']) : 0;

    // handle foto upload
    $foto_name = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $foto_name = 'foto_' . $tipe . '_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['foto']['tmp_name'], '../../../uploads/foto_pre_post/' . $foto_name);
    }

    // cek apakah inspeksi sudah ada
    $cek = mysqli_query($db, "SELECT * FROM inspeksi WHERE booking_id = $booking_id");
    if (mysqli_num_rows($cek)) {
        $row = mysqli_fetch_assoc($cek);
        if ($tipe === 'before') {
            $sql = "UPDATE inspeksi SET tanggal_pre=NOW(), foto_pre='$foto_name', kondisi_pre='$kondisi', catatan=CONCAT(IFNULL(catatan,''), '\n[Before] $catatan') WHERE booking_id=$booking_id";
        } else {
            $sql = "UPDATE inspeksi SET tanggal_post=NOW(), foto_post='$foto_name', kondisi_post='$kondisi', catatan=CONCAT(IFNULL(catatan,''), '\n[After] $catatan'), denda=$denda WHERE booking_id=$booking_id";
        }
    } else {
        if ($tipe === 'before') {
            $sql = "INSERT INTO inspeksi (booking_id, tanggal_pre, foto_pre, kondisi_pre, catatan) VALUES ($booking_id, NOW(), '$foto_name', '$kondisi', '[Before] $catatan')";
        } else {
            $sql = "INSERT INTO inspeksi (booking_id, tanggal_post, foto_post, kondisi_post, catatan, denda) VALUES ($booking_id, NOW(), '$foto_name', '$kondisi', '[After] $catatan', $denda)";
        }
    }

    if (mysqli_query($db, $sql)) {
        header("Location: /proyek-1/pages/checker/checker/dasboard.php");
        exit;
    } else {
        echo "Gagal simpan data inspeksi: " . mysqli_error($db);
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Form Pemeriksaan <?= ucfirst($tipe) ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            max-width: 600px;
            margin: auto;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }

        .btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>
    <h2>Pemeriksaan Mobil (<?= ucfirst($tipe) ?>)</h2>
    <form method="post" action="inspeksi.php?booking_id=<?= $booking_id ?>&tipe=<?= $tipe ?>" enctype="multipart/form-data">
        <label for="foto">Upload Foto (<?= $tipe ?>):</label>
        <input type="file" name="foto" required>

        <label for="kondisi">Kondisi Mobil:</label>
        <select name="kondisi" required>
            <option value="normal">Normal</option>
            <option value="rusak">Rusak</option>
        </select>

        <label for="catatan">Catatan:</label>
        <textarea name="catatan" required></textarea>

        <?php if ($tipe === 'after') : ?>
            <label for="denda">Denda (jika ada):</label>
            <input type="number" name="denda" placeholder="Contoh: 150000">
        <?php endif; ?>

        <button class="btn" type="submit">Simpan Pemeriksaan</button>
    </form>
</body>

</html>