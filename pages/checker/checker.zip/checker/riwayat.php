<?php
session_start();
include '../../../koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'checker') {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../../../vendor/autoload.php';

use Dompdf\Dompdf;

$filter_plat = $_GET['plat'] ?? '';
$filter_denda = $_GET['denda'] ?? '';
$filter_tgl_booking = $_GET['tgl_booking'] ?? '';
$filter_tgl_kembali = $_GET['tgl_kembali'] ?? '';


$sql = "SELECT i.*, b.tgl_booking, b.tgl_kembali, u.id AS unit_mobil_id, u.plat_nomor, us.nama_lengkap
        FROM inspeksi i
        JOIN booking b ON i.booking_id = b.id
        JOIN unit_mobil u ON b.unit_mobil_id = u.id
        JOIN users us ON b.customer_id = us.id
        WHERE 1";

if ($filter_plat) {
    $filter_plat_safe = mysqli_real_escape_string($db, $filter_plat);
    $sql .= " AND u.plat_nomor LIKE '%$filter_plat_safe%'";
}
if ($filter_denda === 'ada') {
    $sql .= " AND i.denda > 0";
} elseif ($filter_denda === 'tidak') {
    $sql .= " AND (i.denda = 0 OR i.denda IS NULL)";
}
if ($filter_tgl_booking) {
    $sql .= " AND DATE(b.tgl_booking) = '$filter_tgl_booking'";
}
if ($filter_tgl_kembali) {
    $sql .= " AND DATE(b.tgl_kembali) = '$filter_tgl_kembali'";
}
$sql .= " ORDER BY i.id DESC";
$result = mysqli_query($db, $sql);

// Export Excel
if (isset($_GET['export']) && $_GET['export'] === 'excel') {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=riwayat_inspeksi.xls");
    echo "<table border='1'>
            <tr>
                <th>Plat</th><th>Customer</th><th>Tgl Booking</th><th>Tgl Kembali</th>
                <th>Kondisi Sebelum</th><th>Kondisi Setelah</th><th>Catatan</th><th>Denda</th>
            </tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['plat_nomor']}</td>
                <td>{$row['nama_lengkap']}</td>
                <td>" . date('d-m-Y', strtotime($row['tgl_booking'])) . "</td>
                <td>" . date('d-m-Y', strtotime($row['tgl_kembali'])) . "</td>
                <td>" . ucfirst($row['kondisi_pre'] ?? '-') . "</td>
                <td>" . ucfirst($row['kondisi_post'] ?? '-') . "</td>
                <td>{$row['catatan']}</td>
                <td>" . ($row['denda'] > 0 ? 'Rp ' . number_format($row['denda'], 0, ',', '.') : '-') . "</td>
              </tr>";
    }
    echo "</table>";
    exit;
}

// Export PDF
if (isset($_GET['export']) && $_GET['export'] === 'pdf') {
    ob_start();
    echo "
    <style>
        body { font-family: Arial, sans-serif; }
        h2 { text-align: center; margin-bottom: 10px; }
        .kop { text-align: center; margin-bottom: 20px; }
        .kop img { width: 80px; height: auto; }
        .kop h3, .kop p { margin: 4px 0; }
        table { border-collapse: collapse; width: 100%; font-size: 12px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: left; }
        th { background: #eee; }
        .ttd { margin-top: 50px; width: 100%; text-align: right; font-size: 12px; }
    </style>
    <div class='kop'>
        <img src='logo.png' alt='Logo'>
        <h3>Rental Mobil Dhela</h3>
        <p>Jl. Contoh Alamat No. 123 - Telp: 0812-3456-7890</p>
    </div>
    <h2>Laporan Riwayat Pemeriksaan Mobil</h2>
    <table>
        <thead><tr>
            <th>Plat</th><th>Customer</th><th>Tgl Booking</th><th>Tgl Kembali</th>
            <th>Kondisi Sebelum</th><th>Kondisi Setelah</th><th>Catatan</th><th>Denda</th>
        </tr></thead><tbody>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
        <td>{$row['plat_nomor']}</td>
        <td>{$row['nama_lengkap']}</td>
        <td>" . date('d-m-Y', strtotime($row['tgl_booking'])) . "</td>
        <td>" . date('d-m-Y', strtotime($row['tgl_kembali'])) . "</td>
        <td>" . ucfirst($row['kondisi_pre'] ?? '-') . "</td>
        <td>" . ucfirst($row['kondisi_post'] ?? '-') . "</td>
        <td>{$row['catatan']}</td>
        <td>" . ($row['denda'] > 0 ? 'Rp ' . number_format($row['denda'], 0, ',', '.') : '-') . "</td>
    </tr>";
    }
    echo "</tbody></table>
    <div class='ttd'>
        <p>Checker,</p><br><br>
        <p><strong>{$_SESSION['nama_lengkap']}</strong></p>
    </div>";

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->render();
    $dompdf->stream("riwayat_pemeriksaan.pdf");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Riwayat Pemeriksaan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 10px;
            border: 1px solid #ccc;
        }

        th {
            background-color: #f0f0f0;
        }

        form {
            margin-bottom: 20px;
        }

        input,
        select {
            padding: 6px;
            margin-right: 10px;
        }

        button {
            padding: 6px 12px;
        }

        .actions {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <h1>Riwayat Pemeriksaan Mobil</h1>

    <form method="get">
        <label>Plat Nomor:
            <input type="text" name="plat" value="<?= htmlspecialchars($filter_plat) ?>">
        </label>
        <label>Denda:
            <select name="denda">
                <option value="">Semua</option>
                <option value="ada" <?= $filter_denda === 'ada' ? 'selected' : '' ?>>Ada Denda</option>
                <option value="tidak" <?= $filter_denda === 'tidak' ? 'selected' : '' ?>>Tanpa Denda</option>
            </select>
        </label>
        <label>Tgl Booking:
            <input type="date" name="tgl_booking" value="<?= htmlspecialchars($filter_tgl_booking) ?>">
        </label>
        <label>Tgl Kembali:
            <input type="date" name="tgl_kembali" value="<?= htmlspecialchars($filter_tgl_kembali) ?>">
        </label>
        <button type="submit">Filter</button>
        <a href="riwayat.php"><button type="button">Reset</button></a>
    </form>

    <div class="actions">
        <a href="riwayat.php?export=excel<?php if ($filter_plat) echo '&plat=' . urlencode($filter_plat);
                                            if ($filter_denda) echo '&denda=' . urlencode($filter_denda);
                                            if ($filter_tgl_booking) echo '&tgl_booking=' . $filter_tgl_booking;
                                            if ($filter_tgl_kembali) echo '&tgl_kembali=' . $filter_tgl_kembali; ?>">
            <button>Export ke Excel</button>
        </a>
        <a href="riwayat.php?export=pdf<?php if ($filter_plat) echo '&plat=' . urlencode($filter_plat);
                                        if ($filter_denda) echo '&denda=' . urlencode($filter_denda);
                                        if ($filter_tgl_booking) echo '&tgl_booking=' . $filter_tgl_booking;
                                        if ($filter_tgl_kembali) echo '&tgl_kembali=' . $filter_tgl_kembali; ?>">
            <button>Export ke PDF</button>
        </a>
    </div>

    <table>
        <tr>
            <th>Plat</th>
            <th>Customer</th>
            <th>Tgl Booking</th>
            <th>Tgl Kembali</th>
            <th>Kondisi Sebelum</th>
            <th>Kondisi Setelah</th>
            <th>Catatan</th>
            <th>Denda</th>
        </tr>
        <?php mysqli_data_seek($result, 0);
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= htmlspecialchars($row['plat_nomor']) ?></td>
                <td><?= htmlspecialchars($row['nama_lengkap']) ?></td>
                <td><?= date('d-m-Y', strtotime($row['tgl_booking'])) ?></td>
                <td><?= date('d-m-Y', strtotime($row['tgl_kembali'])) ?></td>
                <td><?= ucfirst($row['kondisi_pre'] ?? '-') ?></td>
                <td><?= ucfirst($row['kondisi_post'] ?? '-') ?></td>
                <td>
                    <pre><?= htmlspecialchars($row['catatan']) ?></pre>
                </td>
                <td><?= $row['denda'] > 0 ? 'Rp ' . number_format($row['denda'], 0, ',', '.') : '-' ?></td>
            </tr>
        <?php } ?>
    </table>
</body>

</html>