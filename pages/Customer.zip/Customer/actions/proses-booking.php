<?php

require_once 'vendor/autoload.php';
require_once '../../../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['proses_booking'])):


endif;

function membuatTransaksi($data)
{
    // Konfigurasi Midtrans
    \Midtrans\Config::$serverKey = 'SB-Mid-server-uH10eM8NFBYrFd86DHH2kFOw';
    \Midtrans\Config::$isProduction = false; // Sandbox dulu
    \Midtrans\Config::$isSanitized = true;
    \Midtrans\Config::$is3ds = true;

    // Ambil data JSON dari fetch
    $data = json_decode(file_get_contents("php://input"), true);

    

    // Data transaksi
    $params = [
        'transaction_details' => [
            'order_id' => 'ORDER-' . rand(),
            'gross_amount' => $data[''],
        ],
        'customer_details' => [
            'first_name' => 'Budi',
            'last_name' => 'Santoso',
            'email' => 'budi@example.com',
            'phone' => '08123456789',
        ],
    ];

    // Generate token Snap
    $snapToken = \Midtrans\Snap::getSnapToken($params);
    echo "Snap Token: $snapToken";
}

/**
 * Membuat data booking pada database
 * @param mixed $data
 * @return bool|void
 */
function membuatBooking($data)
{
    global $db;

    if (!validasiData($data)):
        echo "Data booking tidak valid";
        return false;
    endif;

    $stmt = mysqli_prepare($db, `
        INSERT INTO booking (
            unit_mobil_id, customer_id, metode_pembayaran, total_biaya, 
            jaminan, tgl_booking, durasi, tgl_kembali, status, fasilitas,
            jam_booking, jam_kembali
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    `);
    mysqli_stmt_bind_param($stmt, "iisississsss", $data);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($db);
}

/**
 * Validasi data booking sebelum membuat transaksi & membuat booking
 * @param mixed $data
 * @return bool|void
 */
function validasiData($data)
{
    foreach ($data as $d):
        if (empty(trim($d))):
            return false;
        endif;
    endforeach;
}
